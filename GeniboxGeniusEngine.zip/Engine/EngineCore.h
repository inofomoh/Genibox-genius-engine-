#pragma once
#include <iostream>

namespace Genibox {
    class EngineCore {
    public:
        void Run() {
            std::cout << "🚀 Genibox Genius Engine is Running: Real-time 3D World, AI, Metahumans, and Streaming Activated!" << std::endl;
        }
    };
}