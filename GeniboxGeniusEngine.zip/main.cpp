#include "Engine/EngineCore.h"

int main() {
    Genibox::EngineCore engine;
    engine.Run();
    return 0;
}